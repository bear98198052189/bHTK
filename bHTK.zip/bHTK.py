from core import *

if __name__ == "__main__":
    manager = ToolKitManager.Manager()
    manager.run()