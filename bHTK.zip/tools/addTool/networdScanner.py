def main():
    print("[Netword Scanner Running]")
    input("계속하려면 Enter를 눌러주세요")
